clear, clc, close all
v = [0 0 -1];
psi = 0;
theta = 90;
phi = 10;
w = aerospace_sequence(psi,theta,phi,v)